﻿using System.Collections.Generic;
using MarsRover.Navigation.Model;
using NUnit.Framework;

namespace MarsRover.Navigation.UnitTests
{
    [TestFixture]
    public class NavigatorTests
    {
        [Test]
        [TestCase(Command.F, Direction.N, 0, 1)]
        [TestCase(Command.B, Direction.N, 0, 5)]
        [TestCase(Command.F, Direction.W, 5, 0)]
        [TestCase(Command.B, Direction.E, 5, 0)]
        public void NavigateForwardBackwardTest(Command command, Direction direction, int expectedX, int expectedY)
        {
            // Assign
            var currentCoordinate = new Coordinate(0, 0) {Direction = direction };

            var navigator = new Navigator(
                new List<ICoordinate>
                {
                    new Coordinate(0, 0),
                    new Coordinate(5, 5)
                },
                currentCoordinate,
                false);

            // Act
            navigator.Navigate(command);

            // Assert
            Assert.AreEqual(expectedX, currentCoordinate.X);
            Assert.AreEqual(expectedY, currentCoordinate.Y);
        }
    }
}
