﻿using System;
using System.Collections.Generic;
using System.Linq;
using MarsRover.Navigation;
using MarsRover.Navigation.Model;

namespace MarsRover
{
    public class Program
    {
        #region Public Methods

        public static void Main(string[] args)
        {
            // Set Upper Coordinate
            string upperCoordinateInput = ReadUserInput("Please insert upper coordinate [Format: x<whitespace>y]. Example: 5 5");
            string[] cood = upperCoordinateInput.Split(' ');
            var upperCoordinate = new Coordinate(int.Parse(cood[0]), int.Parse(cood[1]));

            // Set Current Coordinate
            string currentCoordinateInput = ReadUserInput("Please insert current coordinate [Format: x<whitespace>y<whitespace>N|S|E|W]. Example: 1 2 N");
            string[] currentCood = currentCoordinateInput.Split(' ');

            var currentCoordinate = new Coordinate(
                int.Parse(currentCood[0]),
                int.Parse(currentCood[1]))
            {
                Direction = (Direction)(Enum.Parse(typeof(Direction), currentCood[2], true))
            };

            // Set Commands
            string commandInput = ReadUserInput("Please list of navigation input [Format: F|B|L|R]. Example: LFLFLFLFF");
            IList<Command> commands = ParseCommands(commandInput);

            // Set Generate Random Obstacles
            string randomObstacleInput = ReadUserInput("Generate random obstacle? [Format: Y|N]. Example: N");
            bool randomObstacle = randomObstacleInput.Equals("Y", StringComparison.OrdinalIgnoreCase);

            // Render map and navigator
            IList<ICoordinate> map = RenderMap(upperCoordinate);
            Navigator navigator = new Navigator(map, currentCoordinate, randomObstacle);
            Console.WriteLine($"First Position : {currentCoordinate.CoordinateInString}");

            // Navigate
            foreach (var command in commands)
            {
                bool success = navigator.Navigate(command);
                if (!success)
                {
                    Console.WriteLine("Hit into random obstacle");
                    break;
                }
            }

            Console.WriteLine($"Last Good Position : {currentCoordinate.CoordinateInString}");
            Console.WriteLine("Press any keys to exit...");
            Console.ReadLine();
        }

        #endregion

        #region Private Methods

        private static IList<Command> ParseCommands(string input)
        {
            return input.Select(x => (Command)Enum.Parse(typeof(Command), x.ToString(), true)).ToList();
        }

        private static IList<ICoordinate> RenderMap(ICoordinate upperCoordinateLimit)
        {
            var map = new List<ICoordinate>();
            for (int x = 0; x < upperCoordinateLimit.X + 1; x++)
            {
                for (int y = 0; y < upperCoordinateLimit.Y + 1; y++)
                {
                    var cood = new Coordinate(x, y);
                    map.Add(cood);
                }
            }

            return map;
        }

        private static string ReadUserInput(string message)
        {
            Console.WriteLine(message);
            Console.Write("Input: ");
            return Console.ReadLine();
        }

        #endregion
    }
}
