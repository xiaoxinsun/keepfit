﻿using System;
using System.Collections.Generic;
using System.Linq;
using MarsRover.Navigation.Model;

namespace MarsRover.Navigation
{
    public class Navigator
    {
        #region Fields

        private readonly ICoordinate _lowerLeft;
        private readonly ICoordinate _upperRight;
        private readonly ICoordinate _currentLocation;
        private readonly bool _generateRandomObstacle;
        private static Random _random = new Random();

        #endregion

        #region Constructors

        public Navigator(IList<ICoordinate> map, ICoordinate currentLocation, bool generateRandomObstacle)
        {
            _lowerLeft = map.First();
            _upperRight = map.Last();
            _currentLocation = currentLocation;
            _generateRandomObstacle = generateRandomObstacle;
        }

        #endregion

        #region Public Methods

        public bool Navigate(Command command)
        {
            switch (command)
            {
                case Command.F:
                    return MoveForward(_currentLocation);
                case Command.B:
                    return MoveBackward(_currentLocation);
                case Command.L:
                    RotateLeft(_currentLocation);
                    return true;
                case Command.R:
                    RotateRight(_currentLocation);
                    return true;
                default:
                    throw new InvalidOperationException(command.ToString());
            }
        }

        #endregion

        #region Private Methods

        private bool MoveForward(ICoordinate current)
        {
            ICoordinate destination = new Coordinate(current.X, current.Y) {Direction = current.Direction};

            switch (current.Direction)
            {
                case Direction.N:
                    destination.Y = current.Y + 1 > _upperRight.Y ? _lowerLeft.Y : current.Y + 1;
                    break;
                case Direction.S:
                    destination.Y = current.Y - 1 < _lowerLeft.Y ? _upperRight.Y : current.Y - 1;
                    break;
                case Direction.E:
                    destination.X = current.X + 1 > _upperRight.X ? _lowerLeft.X : current.X + 1;
                    break;
                case Direction.W:
                    destination.X = current.X - 1 < _lowerLeft.X ? _upperRight.X : current.X - 1;
                    break;
                default:
                    throw new InvalidOperationException(current.Direction.ToString());
            }

            return Move(current, destination, Command.F);
        }

        private bool MoveBackward(ICoordinate current)
        {
            ICoordinate destination = new Coordinate(current.X, current.Y) { Direction = current.Direction };

            switch (current.Direction)
            {
                case Direction.N:
                    destination.Y = current.Y - 1 < _lowerLeft.Y ? _upperRight.Y : destination.Y -1;
                    break;
                case Direction.S:
                    destination.Y = current.Y + 1 > _upperRight.Y ? _lowerLeft.Y : destination.Y + 1;
                    break;
                case Direction.E:
                    destination.X = current.X - 1 < _lowerLeft.X ? _upperRight.X : destination.X - 1;
                    break;
                case Direction.W:
                    destination.X = current.X + 1 > _upperRight.X ? _lowerLeft.X : destination.X + 1;
                    break;
                default:
                    throw new InvalidOperationException(current.Direction.ToString());
            }

            return Move(current, destination, Command.B);
        }

        private static void RotateRight(ICoordinate current)
        {
            switch (current.Direction)
            {
                case Direction.N:
                    current.Direction = Direction.E;
                    break;
                case Direction.S:
                    current.Direction = Direction.W;
                    break;
                case Direction.E:
                    current.Direction = Direction.S;
                    break;
                case Direction.W:
                    current.Direction = Direction.N;
                    break;
                default:
                    throw new InvalidOperationException(current.Direction.ToString());
            }

            Console.WriteLine($"Navigated R : {current.CoordinateInString}");
        }

        private static void RotateLeft(ICoordinate current)
        {
            switch (current.Direction)
            {
                case Direction.N:
                    current.Direction = Direction.W;
                    break;
                case Direction.S:
                    current.Direction = Direction.E;
                    break;
                case Direction.E:
                    current.Direction = Direction.N;
                    break;
                case Direction.W:
                    current.Direction = Direction.S;
                    break;
                default:
                    throw new InvalidOperationException(current.Direction.ToString());
            }

            Console.WriteLine($"Navigated L : {current.CoordinateInString}");
        }

        private bool Move(ICoordinate current, ICoordinate destination, Command command)
        {
            if (DetectObstacle())
            {
                return false;
            }

            current.X = destination.X;
            current.Y = destination.Y;
            Console.WriteLine($"Navigated {command.ToString()} : {current.CoordinateInString}");
            return true;
        }

        private bool DetectObstacle()
        {
            if (_generateRandomObstacle)
            {
                return _random.Next(0, 100) > 50;
            }

            return false;
        }

        #endregion
    }
}
