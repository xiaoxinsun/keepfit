﻿namespace MarsRover.Navigation.Model
{
    public enum Direction
    {
        N,
        S,
        E,
        W
    }
}
