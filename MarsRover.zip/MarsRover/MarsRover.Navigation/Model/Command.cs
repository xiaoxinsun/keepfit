﻿namespace MarsRover.Navigation.Model
{
    public enum Command
    {
        F,
        B,
        L,
        R
    }
}
