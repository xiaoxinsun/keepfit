﻿namespace MarsRover.Navigation.Model
{
    public class Coordinate : ICoordinate
    {
        #region Constructors

        public Coordinate(int x, int y)
        {
            X = x;
            Y = y;
        }

        #endregion

        #region Properties

        public int X { get; set; }

        public int Y { get; set; }

        public Direction Direction { get; set; }

        public string CoordinateInString => $"{X} {Y} {Direction}";

        #endregion
    }
}
