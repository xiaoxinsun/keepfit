﻿namespace MarsRover.Navigation.Model
{
    public interface ICoordinate
    {
        int X { get; set; }

        int Y { get; set; }

        Direction Direction { get; set; }

        string CoordinateInString { get; }
    }
}
